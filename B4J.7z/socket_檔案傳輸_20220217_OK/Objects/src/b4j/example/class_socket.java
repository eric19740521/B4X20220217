package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class class_socket extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.class_socket", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.class_socket.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public int _port = 0;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public anywheresoftware.b4a.randomaccessfile.CountingStreams.CountingInput _countingstream = null;
public long _totalsizeforsending = 0L;
public String _currentfile = "";
public boolean _sendingfile = false;
public boolean _receivingfile = false;
public anywheresoftware.b4a.objects.Timer _timer1 = null;
public String _lblfile = "";
public String _progresss1 = "";
public String _progresss2 = "";
public boolean _connected = false;
public String _getmyip = "";
public b4j.example.main _main = null;
public String  _astreams_error() throws Exception{
 //BA.debugLineNum = 161;BA.debugLine="Sub astreams_Error";
 //BA.debugLineNum = 162;BA.debugLine="Log(\"Astream_Error==>\")";
__c.LogImpl("2983041","Astream_Error==>",0);
 //BA.debugLineNum = 163;BA.debugLine="Log(\"Error: \" & LastException)";
__c.LogImpl("2983042","Error: "+BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 166;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 167;BA.debugLine="Connected = False";
_connected = __c.False;
 //BA.debugLineNum = 168;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 147;BA.debugLine="Sub astreams_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 148;BA.debugLine="Log(\"AStream_NewData==>\")";
__c.LogImpl("2917505","AStream_NewData==>",0);
 //BA.debugLineNum = 150;BA.debugLine="ReceivingFile = True";
_receivingfile = __c.True;
 //BA.debugLineNum = 152;BA.debugLine="currentFile = BytesToString(Buffer, 0, Buffer.Len";
_currentfile = __c.BytesToString(_buffer,(int) (0),_buffer.length,"UTF8");
 //BA.debugLineNum = 154;BA.debugLine="Log(\"currentFile: \"&currentFile)";
__c.LogImpl("2917511","currentFile: "+_currentfile,0);
 //BA.debugLineNum = 155;BA.debugLine="lblfile = \"Receiving file: \" & currentFile		'Byte";
_lblfile = "Receiving file: "+_currentfile;
 //BA.debugLineNum = 156;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(__c.True);
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newstream(String _dir,String _filename) throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Sub astreams_NewStream (Dir As String, FileName As";
 //BA.debugLineNum = 131;BA.debugLine="Log(\"AStream_NewStream==>\")";
__c.LogImpl("2851969","AStream_NewStream==>",0);
 //BA.debugLineNum = 132;BA.debugLine="Log(\"DIR: \"&Dir)";
__c.LogImpl("2851970","DIR: "+_dir,0);
 //BA.debugLineNum = 133;BA.debugLine="Log(\"FileName: \"&FileName)";
__c.LogImpl("2851971","FileName: "+_filename,0);
 //BA.debugLineNum = 134;BA.debugLine="Log(\"currentFile: \"&currentFile)";
__c.LogImpl("2851972","currentFile: "+_currentfile,0);
 //BA.debugLineNum = 136;BA.debugLine="lblfile = currentFile & \" completed\"";
_lblfile = _currentfile+" completed";
 //BA.debugLineNum = 137;BA.debugLine="Timer1_Tick";
_timer1_tick();
 //BA.debugLineNum = 138;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(__c.False);
 //BA.debugLineNum = 139;BA.debugLine="ReceivingFile = False";
_receivingfile = __c.False;
 //BA.debugLineNum = 141;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 143;BA.debugLine="File.Copy(Dir, FileName, \"d:\\bak\", currentFile)";
__c.File.Copy(_dir,_filename,"d:\\bak",_currentfile);
 //BA.debugLineNum = 144;BA.debugLine="File.Delete(Dir, FileName)";
__c.File.Delete(_dir,_filename);
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return "";
}
public String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 174;BA.debugLine="Sub astreams_Terminated";
 //BA.debugLineNum = 175;BA.debugLine="Log(\"Astream_Terminated==>\")";
__c.LogImpl("21048577","Astream_Terminated==>",0);
 //BA.debugLineNum = 177;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 178;BA.debugLine="Connected = False";
_connected = __c.False;
 //BA.debugLineNum = 179;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 180;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private socket1 As Socket";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 5;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Private port As Int = 21341";
_port = (int) (21341);
 //BA.debugLineNum = 7;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 10;BA.debugLine="Private countingStream As CountingInputStream";
_countingstream = new anywheresoftware.b4a.randomaccessfile.CountingStreams.CountingInput();
 //BA.debugLineNum = 11;BA.debugLine="Private totalSizeForSending As Long";
_totalsizeforsending = 0L;
 //BA.debugLineNum = 12;BA.debugLine="Private currentFile As String";
_currentfile = "";
 //BA.debugLineNum = 14;BA.debugLine="Public SendingFile As Boolean";
_sendingfile = false;
 //BA.debugLineNum = 15;BA.debugLine="Public ReceivingFile As Boolean";
_receivingfile = false;
 //BA.debugLineNum = 16;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 19;BA.debugLine="Public lblfile,ProgressS1,ProgressS2 As String";
_lblfile = "";
_progresss1 = "";
_progresss2 = "";
 //BA.debugLineNum = 20;BA.debugLine="Public Connected As Boolean";
_connected = false;
 //BA.debugLineNum = 21;BA.debugLine="Public GetMyIP As String";
_getmyip = "";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _connecttoserver(String _ip) throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Public Sub ConnectToServer(IP As String)";
 //BA.debugLineNum = 95;BA.debugLine="socket1.Initialize(\"socket1\")";
_socket1.Initialize("socket1");
 //BA.debugLineNum = 96;BA.debugLine="socket1.Connect( IP , port, 30000)";
_socket1.Connect(ba,_ip,_port,(int) (30000));
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _disconnect() throws Exception{
 //BA.debugLineNum = 56;BA.debugLine="public Sub Disconnect";
 //BA.debugLineNum = 59;BA.debugLine="If astream.IsInitialized Then astream.Close";
if (_astream.IsInitialized()) { 
_astream.Close();};
 //BA.debugLineNum = 60;BA.debugLine="If socket1.IsInitialized Then socket1.Close";
if (_socket1.IsInitialized()) { 
_socket1.Close();};
 //BA.debugLineNum = 62;BA.debugLine="UpdateUI 	'UI介面 更新狀態";
_updateui();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,int _iport) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize(iport As Int)";
 //BA.debugLineNum = 26;BA.debugLine="Log(\"Initialize==>\")";
__c.LogImpl("2524289","Initialize==>",0);
 //BA.debugLineNum = 28;BA.debugLine="port=iport";
_port = _iport;
 //BA.debugLineNum = 30;BA.debugLine="lblfile=\"\"";
_lblfile = "";
 //BA.debugLineNum = 31;BA.debugLine="ProgressS1=\"\"";
_progresss1 = "";
 //BA.debugLineNum = 32;BA.debugLine="ProgressS2=\"\"";
_progresss2 = "";
 //BA.debugLineNum = 33;BA.debugLine="Connected=False";
_connected = __c.False;
 //BA.debugLineNum = 37;BA.debugLine="timer1.Initialize(\"timer1\", 1000)";
_timer1.Initialize(ba,"timer1",(long) (1000));
 //BA.debugLineNum = 38;BA.debugLine="timer1.Enabled=False";
_timer1.setEnabled(__c.False);
 //BA.debugLineNum = 41;BA.debugLine="server.Initialize(port, \"server\")";
_server.Initialize(ba,_port,"server");
 //BA.debugLineNum = 43;BA.debugLine="GetMyIP=server.GetMyIP";
_getmyip = _server.GetMyIP();
 //BA.debugLineNum = 44;BA.debugLine="Try";
try { //BA.debugLineNum = 45;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e14) {
			ba.setLastException(e14); //BA.debugLineNum = 48;BA.debugLine="Log(\"server 出錯了???\"& LastException)";
__c.LogImpl("2524311","server 出錯了???"+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 51;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public String  _sendfile(String _dir,String _filename) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
 //BA.debugLineNum = 184;BA.debugLine="Public Sub SendFile(Dir As String, FileName As Str";
 //BA.debugLineNum = 185;BA.debugLine="Log(\"SendFile==>\")";
__c.LogImpl("21114113","SendFile==>",0);
 //BA.debugLineNum = 188;BA.debugLine="totalSizeForSending  = File.Size(Dir, FileName)";
_totalsizeforsending = __c.File.Size(_dir,_filename);
 //BA.debugLineNum = 189;BA.debugLine="Dim In As InputStream = File.OpenInput(Dir, FileN";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
_in = __c.File.OpenInput(_dir,_filename);
 //BA.debugLineNum = 190;BA.debugLine="countingStream.Initialize(In)";
_countingstream.Initialize((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 191;BA.debugLine="currentFile = FileName.SubString(FileName.LastInd";
_currentfile = _filename.substring((int) (_filename.lastIndexOf("\\")+1));
 //BA.debugLineNum = 193;BA.debugLine="Log(\"準備送出...\" )";
__c.LogImpl("21114121","準備送出...",0);
 //BA.debugLineNum = 194;BA.debugLine="Log(\"檔案名稱: \" & currentFile)";
__c.LogImpl("21114122","檔案名稱: "+_currentfile,0);
 //BA.debugLineNum = 195;BA.debugLine="Log(\"檔案大小: \" & totalSizeForSending)";
__c.LogImpl("21114123","檔案大小: "+BA.NumberToString(_totalsizeforsending),0);
 //BA.debugLineNum = 197;BA.debugLine="Try";
try { //BA.debugLineNum = 199;BA.debugLine="astream.Write(currentFile.GetBytes(\"UTF8\")) 'wri";
_astream.Write(_currentfile.getBytes("UTF8"));
 //BA.debugLineNum = 200;BA.debugLine="astream.WriteStream(countingStream, totalSizeFor";
_astream.WriteStream((java.io.InputStream)(_countingstream.getObject()),_totalsizeforsending);
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 203;BA.debugLine="Log(\"傳送時出錯...\")";
__c.LogImpl("21114131","傳送時出錯...",0);
 //BA.debugLineNum = 204;BA.debugLine="Log(LastException)";
__c.LogImpl("21114132",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 207;BA.debugLine="lblfile = \"Sending: \" & currentFile";
_lblfile = "Sending: "+_currentfile;
 //BA.debugLineNum = 208;BA.debugLine="SendingFile = True";
_sendingfile = __c.True;
 //BA.debugLineNum = 209;BA.debugLine="ProgressS2 = NumberFormat(0, 0, 2)";
_progresss2 = __c.NumberFormat(0,(int) (0),(int) (2));
 //BA.debugLineNum = 211;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(__c.True);
 //BA.debugLineNum = 214;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Private Sub server_NewConnection (Successful As Bo";
 //BA.debugLineNum = 70;BA.debugLine="Log(\"server_NewConnection==>\")";
__c.LogImpl("2655361","server_NewConnection==>",0);
 //BA.debugLineNum = 72;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 73;BA.debugLine="socket1 = NewSocket";
_socket1 = _newsocket;
 //BA.debugLineNum = 76;BA.debugLine="astream.InitializePrefix( socket1.InputStream, F";
_astream.InitializePrefix(ba,_socket1.getInputStream(),__c.False,_socket1.getOutputStream(),"astreams");
 //BA.debugLineNum = 82;BA.debugLine="Connected = True";
_connected = __c.True;
 }else {
 //BA.debugLineNum = 84;BA.debugLine="Connected = False";
_connected = __c.False;
 //BA.debugLineNum = 85;BA.debugLine="Log(\"server_NewConnection連線失敗: \" & LastException";
__c.LogImpl("2655376","server_NewConnection連線失敗: "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 87;BA.debugLine="UpdateUI	'更新介面";
_updateui();
 //BA.debugLineNum = 89;BA.debugLine="server.Listen	'處裡完使用者的連線.要啟動聆聽";
_server.Listen();
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _socket1_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Private Sub socket1_Connected (Successful As Boole";
 //BA.debugLineNum = 102;BA.debugLine="Log(\"socket1_Connected==>\")";
__c.LogImpl("2786433","socket1_Connected==>",0);
 //BA.debugLineNum = 104;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 108;BA.debugLine="astream.InitializePrefix(socket1.InputStream, Fa";
_astream.InitializePrefix(ba,_socket1.getInputStream(),__c.False,_socket1.getOutputStream(),"astreams");
 //BA.debugLineNum = 114;BA.debugLine="Connected = True";
_connected = __c.True;
 }else {
 //BA.debugLineNum = 118;BA.debugLine="Connected = False";
_connected = __c.False;
 //BA.debugLineNum = 120;BA.debugLine="Log(\"socket1_Connected連線失敗: \" & LastException)";
__c.LogImpl("2786451","socket1_Connected連線失敗: "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 123;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public String  _timer1_tick() throws Exception{
long _count = 0L;
long _total = 0L;
 //BA.debugLineNum = 217;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 218;BA.debugLine="Dim count, total As Long";
_count = 0L;
_total = 0L;
 //BA.debugLineNum = 221;BA.debugLine="If SendingFile Then";
if (_sendingfile) { 
 //BA.debugLineNum = 222;BA.debugLine="count = countingStream.count";
_count = _countingstream.getCount();
 //BA.debugLineNum = 223;BA.debugLine="total = totalSizeForSending";
_total = _totalsizeforsending;
 //BA.debugLineNum = 224;BA.debugLine="If count = total Then";
if (_count==_total) { 
 //BA.debugLineNum = 226;BA.debugLine="lblfile = currentFile & \" completed\"";
_lblfile = _currentfile+" completed";
 //BA.debugLineNum = 229;BA.debugLine="SendingFile = False";
_sendingfile = __c.False;
 //BA.debugLineNum = 230;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(__c.False);
 };
 }else if(_receivingfile) { 
 //BA.debugLineNum = 233;BA.debugLine="count = astream.StreamReceived";
_count = _astream.getStreamReceived();
 //BA.debugLineNum = 234;BA.debugLine="total = astream.StreamTotal";
_total = _astream.getStreamTotal();
 };
 //BA.debugLineNum = 237;BA.debugLine="ProgressS2 = NumberFormat(100 * count / total, 0,";
_progresss2 = __c.NumberFormat(100*_count/(double)_total,(int) (0),(int) (2));
 //BA.debugLineNum = 238;BA.debugLine="ProgressS1 = NumberFormat2(count / 1000, 0, 0, 0,";
_progresss1 = __c.NumberFormat2(_count/(double)1000,(int) (0),(int) (0),(int) (0),__c.True)+"kb / "+__c.NumberFormat2(_total/(double)1000,(int) (0),(int) (0),(int) (0),__c.True)+"kb";
 //BA.debugLineNum = 241;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 242;BA.debugLine="End Sub";
return "";
}
public String  _updateprogress() throws Exception{
 //BA.debugLineNum = 251;BA.debugLine="Public Sub UpdateProgress";
 //BA.debugLineNum = 252;BA.debugLine="Log(\"UpdateProgress==>\")";
__c.LogImpl("21310721","UpdateProgress==>",0);
 //BA.debugLineNum = 255;BA.debugLine="CallSub(\"Main\",\"UpdateProgress\")";
__c.CallSubNew(ba,(Object)("Main"),"UpdateProgress");
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
return "";
}
public String  _updateui() throws Exception{
 //BA.debugLineNum = 245;BA.debugLine="Sub UpdateUI";
 //BA.debugLineNum = 247;BA.debugLine="CallSub(\"Main\",\"UpdateUI\")";
__c.CallSubNew(ba,(Object)("Main"),"UpdateUI");
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "UPDATEPROGRESS"))
	return _updateprogress();
if (BA.fastSubCompare(sub, "UPDATEUI"))
	return _updateui();
return BA.SubDelegator.SubNotFound;
}
}
