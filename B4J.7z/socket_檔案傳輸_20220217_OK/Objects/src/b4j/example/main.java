package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static b4j.example.class_socket _srv = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _btnsendfile = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblwifistatus = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtip = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _progressvalue = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _progresstext = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblip = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _progressbar1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblfile = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblprogress = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _btnconnect = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 29;BA.debugLine="LogColor(\"AppStart\",xui.Color_Green )";
anywheresoftware.b4a.keywords.Common.LogImpl("265537","AppStart",_xui.Color_Green);
 //BA.debugLineNum = 31;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 32;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 33;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 37;BA.debugLine="srv.Initialize(51042)";
_srv._initialize /*String*/ (ba,(int) (51042));
 //BA.debugLineNum = 40;BA.debugLine="progressValue.text = \"\"";
_progressvalue.setText("");
 //BA.debugLineNum = 41;BA.debugLine="progressText.text = \"\"";
_progresstext.setText("");
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnect_click() throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Private Sub btnConnect_Click";
 //BA.debugLineNum = 54;BA.debugLine="Log(\"btnConnect_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2196609","btnConnect_Click==>",0);
 //BA.debugLineNum = 56;BA.debugLine="If srv.Connected==False Then";
if (_srv._connected /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 57;BA.debugLine="If txtIP.Text.Length=0 Then";
if (_txtip.getText().length()==0) { 
 //BA.debugLineNum = 58;BA.debugLine="xui.MsgboxAsync(\"請先輸入IP\", \"FT\")";
_xui.MsgboxAsync(ba,"請先輸入IP","FT");
 }else {
 //BA.debugLineNum = 60;BA.debugLine="srv.ConnectToServer(txtIP.text)";
_srv._connecttoserver /*String*/ (_txtip.getText());
 };
 }else {
 //BA.debugLineNum = 65;BA.debugLine="srv.Disconnect		'服務中斷";
_srv._disconnect /*String*/ ();
 };
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public static String  _btnsendfile_click() throws Exception{
anywheresoftware.b4j.objects.FileChooserWrapper _fc = null;
String _name = "";
 //BA.debugLineNum = 71;BA.debugLine="Private Sub btnSendFile_Click";
 //BA.debugLineNum = 72;BA.debugLine="Log(\"btnSendFile_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2262145","btnSendFile_Click==>",0);
 //BA.debugLineNum = 74;BA.debugLine="Dim fc As FileChooser";
_fc = new anywheresoftware.b4j.objects.FileChooserWrapper();
 //BA.debugLineNum = 76;BA.debugLine="fc.Initialize";
_fc.Initialize();
 //BA.debugLineNum = 77;BA.debugLine="fc.InitialDirectory = File.DirApp";
_fc.setInitialDirectory(anywheresoftware.b4a.keywords.Common.File.getDirApp());
 //BA.debugLineNum = 78;BA.debugLine="Dim name As String = fc.ShowOpen(MainForm)";
_name = _fc.ShowOpen(_mainform);
 //BA.debugLineNum = 80;BA.debugLine="Log(\"name: \"&name)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262153","name: "+_name,0);
 //BA.debugLineNum = 82;BA.debugLine="If name<>\"\" Then";
if ((_name).equals("") == false) { 
 //BA.debugLineNum = 83;BA.debugLine="srv.SendFile(\"\", name)	'傳送檔案";
_srv._sendfile /*String*/ ("",_name);
 }else {
 //BA.debugLineNum = 86;BA.debugLine="xui.MsgboxAsync(\"傳輸中斷,因為沒有選到檔案\", \"FT\")";
_xui.MsgboxAsync(ba,"傳輸中斷,因為沒有選到檔案","FT");
 };
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_closed() throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub MainForm_Closed";
 //BA.debugLineNum = 47;BA.debugLine="Log(\"Form_Closed==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2131073","Form_Closed==>",0);
 //BA.debugLineNum = 49;BA.debugLine="srv.Disconnect		'服務中斷";
_srv._disconnect /*String*/ ();
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private srv As class_socket";
_srv = new b4j.example.class_socket();
 //BA.debugLineNum = 14;BA.debugLine="Private btnSendFile As B4XView";
_btnsendfile = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblWifiStatus As B4XView";
_lblwifistatus = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private txtIP As B4XView";
_txtip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private progressValue As B4XView";
_progressvalue = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private progressText As B4XView";
_progresstext = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private lblIP As B4XView";
_lblip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private ProgressBar1 As B4XView";
_progressbar1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private lblFile As B4XView";
_lblfile = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private lblProgress As B4XView";
_lblprogress = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private btnConnect As B4XView";
_btnconnect = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _updateprogress() throws Exception{
 //BA.debugLineNum = 113;BA.debugLine="Public Sub UpdateProgress";
 //BA.debugLineNum = 114;BA.debugLine="Log(\"UpdateProgress==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2393217","UpdateProgress==>",0);
 //BA.debugLineNum = 116;BA.debugLine="Log(\"ProgressS1: \"&srv.ProgressS1)";
anywheresoftware.b4a.keywords.Common.LogImpl("2393219","ProgressS1: "+_srv._progresss1 /*String*/ ,0);
 //BA.debugLineNum = 117;BA.debugLine="Log(\"ProgressS2: \"&srv.ProgressS2)";
anywheresoftware.b4a.keywords.Common.LogImpl("2393220","ProgressS2: "+_srv._progresss2 /*String*/ ,0);
 //BA.debugLineNum = 119;BA.debugLine="Try";
try { //BA.debugLineNum = 121;BA.debugLine="lblProgress.Text = srv.ProgressS1		'進度狀態:檔名.狀態";
_lblprogress.setText(_srv._progresss1 /*String*/ );
 //BA.debugLineNum = 122;BA.debugLine="ProgressBar1.Progress =srv.ProgressS2	'進度表.數字";
_progressbar1.setProgress((int)(Double.parseDouble(_srv._progresss2 /*String*/ )));
 //BA.debugLineNum = 123;BA.debugLine="lblFile.Text = srv.lblFile";
_lblfile.setText(_srv._lblfile /*String*/ );
 } 
       catch (Exception e9) {
			ba.setLastException(e9); //BA.debugLineNum = 125;BA.debugLine="Log(\"UpdateProgress 錯誤羅!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2393228","UpdateProgress 錯誤羅!!",0);
 //BA.debugLineNum = 126;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("2393229",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return "";
}
public static String  _updateui() throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Public Sub UpdateUI";
 //BA.debugLineNum = 96;BA.debugLine="lblIP.Text = srv.GetMyIP";
_lblip.setText(_srv._getmyip /*String*/ );
 //BA.debugLineNum = 97;BA.debugLine="If srv.Connected Then";
if (_srv._connected /*boolean*/ ) { 
 //BA.debugLineNum = 98;BA.debugLine="lblWifiStatus.Text=\"連接\"";
_lblwifistatus.setText("連接");
 //BA.debugLineNum = 100;BA.debugLine="btnConnect.Enabled =False";
_btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 101;BA.debugLine="btnSendFile.Enabled =True";
_btnsendfile.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 104;BA.debugLine="lblWifiStatus.Text=\"未連\"";
_lblwifistatus.setText("未連");
 //BA.debugLineNum = 106;BA.debugLine="btnConnect.Enabled =True";
_btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 107;BA.debugLine="btnSendFile.Enabled =False";
_btnsendfile.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
}
