package b4a.example.filetransfer;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class filetranser extends  android.app.Service{
	public static class filetranser_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (filetranser) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, filetranser.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static filetranser mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return filetranser.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "b4a.example.filetransfer", "b4a.example.filetransfer.filetranser");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.filetransfer.filetranser", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, true) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (filetranser) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (filetranser) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (filetranser) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (filetranser) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (filetranser) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static String _myip = "";
public static String _wifistatus = "";
public static String _btstatus = "";
public static boolean _wificonnected = false;
public static boolean _btconnected = false;
public static int _progressvalue = 0;
public static String _progresstext = "";
public static String _lblfile = "";
public static boolean _sendingfile = false;
public static boolean _receivingfile = false;
public static anywheresoftware.b4a.objects.Serial.BluetoothAdmin _admin = null;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static anywheresoftware.b4a.objects.Serial _serial1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static int _port = 0;
public static String _uuid = "";
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static anywheresoftware.b4a.phone.PhoneEvents _pe = null;
public static anywheresoftware.b4a.randomaccessfile.CountingStreams.CountingInput _countingstream = null;
public static long _totalsizeforsending = 0L;
public static String _currentfile = "";
public b4a.example.filetransfer.main _main = null;
public static String  _admin_statechanged(int _newstate,int _oldstate) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub admin_StateChanged (NewState As Int, OldState";
 //BA.debugLineNum = 47;BA.debugLine="If NewState = admin.STATE_ON Then serial1.Listen2";
if (_newstate==_admin.STATE_ON) { 
_serial1.Listen2("na",_uuid,processBA);};
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public static String  _astream_error() throws Exception{
 //BA.debugLineNum = 148;BA.debugLine="Sub Astream_Error";
 //BA.debugLineNum = 149;BA.debugLine="Log(\"Astream_Error==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52359297","Astream_Error==>",0);
 //BA.debugLineNum = 151;BA.debugLine="Log(\"Error: \" & LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("52359299","Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)),0);
 //BA.debugLineNum = 152;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 153;BA.debugLine="AStream_Terminated 'manually call this method as";
_astream_terminated();
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 216;BA.debugLine="Sub AStream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 217;BA.debugLine="Log(\"AStream_NewData==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52555905","AStream_NewData==>",0);
 //BA.debugLineNum = 219;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 220;BA.debugLine="currentFile = BytesToString(Buffer, 0, Buffer.Len";
_currentfile = anywheresoftware.b4a.keywords.Common.BytesToString(_buffer,(int) (0),_buffer.length,"UTF8");
 //BA.debugLineNum = 221;BA.debugLine="lblFile = \"Receiving file: \" & currentFile";
_lblfile = "Receiving file: "+_currentfile;
 //BA.debugLineNum = 222;BA.debugLine="ReceivingFile = True";
_receivingfile = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newstream(String _dir,String _filename) throws Exception{
 //BA.debugLineNum = 174;BA.debugLine="Sub AStream_NewStream (Dir As String, FileName As";
 //BA.debugLineNum = 175;BA.debugLine="Log(\"AStream_NewStream==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52490369","AStream_NewStream==>",0);
 //BA.debugLineNum = 176;BA.debugLine="Log(\"DIR: \"&Dir)";
anywheresoftware.b4a.keywords.Common.LogImpl("52490370","DIR: "+_dir,0);
 //BA.debugLineNum = 177;BA.debugLine="Log(\"FileName: \"&FileName)";
anywheresoftware.b4a.keywords.Common.LogImpl("52490371","FileName: "+_filename,0);
 //BA.debugLineNum = 178;BA.debugLine="Log(\"currentFile: \"&currentFile)";
anywheresoftware.b4a.keywords.Common.LogImpl("52490372","currentFile: "+_currentfile,0);
 //BA.debugLineNum = 180;BA.debugLine="Log(\"File.DirDefaultExternal: \"&File.DirDefaultEx";
anywheresoftware.b4a.keywords.Common.LogImpl("52490374","File.DirDefaultExternal: "+anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),0);
 //BA.debugLineNum = 181;BA.debugLine="Log(\"File.DirRootExternal: \"&File.DirRootExternal";
anywheresoftware.b4a.keywords.Common.LogImpl("52490375","File.DirRootExternal: "+anywheresoftware.b4a.keywords.Common.File.getDirRootExternal(),0);
 //BA.debugLineNum = 184;BA.debugLine="Timer1_Tick";
_timer1_tick();
 //BA.debugLineNum = 185;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 186;BA.debugLine="lblFile = currentFile & \" completed\"";
_lblfile = _currentfile+" completed";
 //BA.debugLineNum = 187;BA.debugLine="ReceivingFile = False";
_receivingfile = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 188;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 189;BA.debugLine="Try";
try { //BA.debugLineNum = 193;BA.debugLine="File.Copy(Dir, FileName, File.DirDefaultExternal";
anywheresoftware.b4a.keywords.Common.File.Copy(_dir,_filename,anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),_currentfile);
 //BA.debugLineNum = 194;BA.debugLine="File.Delete(Dir, FileName)";
anywheresoftware.b4a.keywords.Common.File.Delete(_dir,_filename);
 } 
       catch (Exception e16) {
			processBA.setLastException(e16); //BA.debugLineNum = 197;BA.debugLine="Log(\"AStream_NewStream出錯了==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52490391","AStream_NewStream出錯了==>",0);
 //BA.debugLineNum = 198;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("52490392",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)),0);
 };
 //BA.debugLineNum = 213;BA.debugLine="End Sub";
return "";
}
public static String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 157;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 158;BA.debugLine="Log(\"AStream_Terminated==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52424833","AStream_Terminated==>",0);
 //BA.debugLineNum = 160;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 161;BA.debugLine="If BTConnected Then";
if (_btconnected) { 
 //BA.debugLineNum = 162;BA.debugLine="BTStatus = \"Disconnected\"";
_btstatus = "Disconnected";
 }else if(_wificonnected) { 
 //BA.debugLineNum = 164;BA.debugLine="WifiStatus = \"Disconnected\"";
_wifistatus = "Disconnected";
 };
 //BA.debugLineNum = 166;BA.debugLine="BTConnected = False";
_btconnected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 167;BA.debugLine="WifiConnected = False";
_wificonnected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 168;BA.debugLine="ReceivingFile = False";
_receivingfile = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 169;BA.debugLine="SendingFile = False";
_sendingfile = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 170;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public static String  _connectbt(String _address) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Public Sub ConnectBT(Address As String)";
 //BA.debugLineNum = 71;BA.debugLine="serial1.Connect2(Address, uuid)";
_serial1.Connect2(processBA,_address,_uuid);
 //BA.debugLineNum = 72;BA.debugLine="BTStatus = \"Trying to connect...\"";
_btstatus = "Trying to connect...";
 //BA.debugLineNum = 73;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public static String  _connectwifi(String _ip) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Public Sub ConnectWifi(Ip As String)";
 //BA.debugLineNum = 77;BA.debugLine="socket1.Initialize(\"socket1\")";
_socket1.Initialize("socket1");
 //BA.debugLineNum = 78;BA.debugLine="socket1.Connect(Ip, port, 30000)";
_socket1.Connect(processBA,_ip,_port,(int) (30000));
 //BA.debugLineNum = 79;BA.debugLine="WifiStatus = \"Trying to connect...\"";
_wifistatus = "Trying to connect...";
 //BA.debugLineNum = 80;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public static String  _disconnect() throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Public Sub Disconnect";
 //BA.debugLineNum = 65;BA.debugLine="If WifiConnected Or BTConnected Then";
if (_wificonnected || _btconnected) { 
 //BA.debugLineNum = 66;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 67;BA.debugLine="AStream_Terminated";
_astream_terminated();
 };
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public static String  _pe_connectivitychanged(String _networktype,String _state,anywheresoftware.b4a.objects.IntentWrapper _intent) throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Sub pe_ConnectivityChanged (NetworkType As String,";
 //BA.debugLineNum = 51;BA.debugLine="MyIP = server.GetMyWifiIP";
_myip = _server.GetMyWifiIP();
 //BA.debugLineNum = 52;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Public MyIP As String = \"N/A\"";
_myip = "N/A";
 //BA.debugLineNum = 7;BA.debugLine="Public WifiStatus As String = \"Diconnected\"";
_wifistatus = "Diconnected";
 //BA.debugLineNum = 8;BA.debugLine="Public BTStatus  As String = \"Diconnected\"";
_btstatus = "Diconnected";
 //BA.debugLineNum = 9;BA.debugLine="Public WifiConnected, BTConnected As Boolean";
_wificonnected = false;
_btconnected = false;
 //BA.debugLineNum = 10;BA.debugLine="Public progressValue As Int";
_progressvalue = 0;
 //BA.debugLineNum = 11;BA.debugLine="Public progressText, lblFile As String";
_progresstext = "";
_lblfile = "";
 //BA.debugLineNum = 12;BA.debugLine="Public SendingFile As Boolean";
_sendingfile = false;
 //BA.debugLineNum = 13;BA.debugLine="Public ReceivingFile As Boolean";
_receivingfile = false;
 //BA.debugLineNum = 15;BA.debugLine="Private admin As BluetoothAdmin";
_admin = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 16;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 17;BA.debugLine="Private serial1 As Serial";
_serial1 = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 18;BA.debugLine="Private socket1 As Socket";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private port As Int = 51042";
_port = (int) (51042);
 //BA.debugLineNum = 21;BA.debugLine="Private uuid As String = \"dabcabcd-afac-11de-8a39";
_uuid = "dabcabcd-afac-11de-8a39-0800200c9a6";
 //BA.debugLineNum = 22;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 23;BA.debugLine="Private pe As PhoneEvents";
_pe = new anywheresoftware.b4a.phone.PhoneEvents();
 //BA.debugLineNum = 24;BA.debugLine="Private countingStream As CountingInputStream";
_countingstream = new anywheresoftware.b4a.randomaccessfile.CountingStreams.CountingInput();
 //BA.debugLineNum = 25;BA.debugLine="Private totalSizeForSending As Long";
_totalsizeforsending = 0L;
 //BA.debugLineNum = 26;BA.debugLine="Private currentFile As String";
_currentfile = "";
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public static String  _sendfile(String _dir,String _filename) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
 //BA.debugLineNum = 83;BA.debugLine="Public Sub SendFile(Dir As String, FileName As Str";
 //BA.debugLineNum = 84;BA.debugLine="Dim totalSizeForSending As Long = File.Size(Dir,";
_totalsizeforsending = anywheresoftware.b4a.keywords.Common.File.Size(_dir,_filename);
 //BA.debugLineNum = 85;BA.debugLine="Dim In As InputStream = File.OpenInput(Dir, FileN";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
_in = anywheresoftware.b4a.keywords.Common.File.OpenInput(_dir,_filename);
 //BA.debugLineNum = 86;BA.debugLine="countingStream.Initialize(In)";
_countingstream.Initialize((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 87;BA.debugLine="currentFile = FileName.SubString(FileName.LastInd";
_currentfile = _filename.substring((int) (_filename.lastIndexOf("/")+1));
 //BA.debugLineNum = 88;BA.debugLine="astream.Write(currentFile.GetBytes(\"UTF8\")) 'writ";
_astream.Write(_currentfile.getBytes("UTF8"));
 //BA.debugLineNum = 89;BA.debugLine="astream.WriteStream(countingStream, totalSizeForS";
_astream.WriteStream((java.io.InputStream)(_countingstream.getObject()),_totalsizeforsending);
 //BA.debugLineNum = 90;BA.debugLine="lblFile = \"Sending: \" & currentFile";
_lblfile = "Sending: "+_currentfile;
 //BA.debugLineNum = 91;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 92;BA.debugLine="SendingFile = True";
_sendingfile = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 93;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public static String  _serial1_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub serial1_Connected (Success As Boolean)";
 //BA.debugLineNum = 122;BA.debugLine="If Success Then";
if (_success) { 
 //BA.debugLineNum = 123;BA.debugLine="BTStatus = \"Connected\"";
_btstatus = "Connected";
 //BA.debugLineNum = 124;BA.debugLine="BTConnected = True";
_btconnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 125;BA.debugLine="StartAStream(serial1.InputStream, serial1.Output";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_serial1.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_serial1.getOutputStream())));
 }else {
 //BA.debugLineNum = 127;BA.debugLine="BTStatus = \"Error: \" & LastException.Message";
_btstatus = "Error: "+anywheresoftware.b4a.keywords.Common.LastException(processBA).getMessage();
 };
 //BA.debugLineNum = 129;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 108;BA.debugLine="Private Sub server_NewConnection (Successful As Bo";
 //BA.debugLineNum = 110;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 111;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 112;BA.debugLine="StartAStream(NewSocket.InputStream, NewSocket.Ou";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_newsocket.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_newsocket.getOutputStream())));
 //BA.debugLineNum = 113;BA.debugLine="WifiStatus = \"Connected\"";
_wifistatus = "Connected";
 }else {
 //BA.debugLineNum = 115;BA.debugLine="WifiStatus = \"Error: \" & LastException";
_wifistatus = "Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 };
 //BA.debugLineNum = 117;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 118;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 31;BA.debugLine="server.Initialize(port, \"server\")";
_server.Initialize(processBA,_port,"server");
 //BA.debugLineNum = 32;BA.debugLine="Try";
try { //BA.debugLineNum = 33;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e5) {
			processBA.setLastException(e5); //BA.debugLineNum = 35;BA.debugLine="WifiStatus = \"Error listening: \" & LastException";
_wifistatus = "Error listening: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 //BA.debugLineNum = 36;BA.debugLine="UpdateUI";
_updateui();
 };
 //BA.debugLineNum = 38;BA.debugLine="admin.Initialize(\"admin\")";
_admin.Initialize(processBA,"admin");
 //BA.debugLineNum = 39;BA.debugLine="serial1.Initialize(\"serial1\")";
_serial1.Initialize("serial1");
 //BA.debugLineNum = 40;BA.debugLine="If serial1.IsEnabled Then serial1.Listen2(\"na\", u";
if (_serial1.IsEnabled()) { 
_serial1.Listen2("na",_uuid,processBA);};
 //BA.debugLineNum = 41;BA.debugLine="pe.Initialize(\"pe\")";
_pe.Initialize(processBA,"pe");
 //BA.debugLineNum = 42;BA.debugLine="pe_ConnectivityChanged(\"\", \"\", Null)";
_pe_connectivitychanged("","",(anywheresoftware.b4a.objects.IntentWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.IntentWrapper(), (android.content.Intent)(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 43;BA.debugLine="timer1.Initialize(\"timer1\", 1000)";
_timer1.Initialize(processBA,"timer1",(long) (1000));
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 248;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 250;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _socket1_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 96;BA.debugLine="Private Sub socket1_Connected (Successful As Boole";
 //BA.debugLineNum = 98;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 99;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 100;BA.debugLine="StartAStream(socket1.InputStream, socket1.Output";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_socket1.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_socket1.getOutputStream())));
 //BA.debugLineNum = 101;BA.debugLine="WifiStatus = \"Connected\"";
_wifistatus = "Connected";
 }else {
 //BA.debugLineNum = 103;BA.debugLine="WifiStatus = \"Error: \" & LastException";
_wifistatus = "Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 };
 //BA.debugLineNum = 105;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public static String  _startastream(anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in,anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Private Sub StartAStream (In As InputStream, out A";
 //BA.debugLineNum = 133;BA.debugLine="Log(\"StartAStream\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52293761","StartAStream",0);
 //BA.debugLineNum = 136;BA.debugLine="astream.InitializePrefix(In, False, out, \"astream";
_astream.InitializePrefix(processBA,(java.io.InputStream)(_in.getObject()),anywheresoftware.b4a.keywords.Common.False,(java.io.OutputStream)(_out.getObject()),"astream");
 //BA.debugLineNum = 140;BA.debugLine="astream.StreamFolder = File.DirRootExternal";
_astream.StreamFolder = anywheresoftware.b4a.keywords.Common.File.getDirRootExternal();
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
long _count = 0L;
long _total = 0L;
 //BA.debugLineNum = 225;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 226;BA.debugLine="Log(\"Timer1_Tick==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52621441","Timer1_Tick==>",0);
 //BA.debugLineNum = 227;BA.debugLine="Dim count, total As Long";
_count = 0L;
_total = 0L;
 //BA.debugLineNum = 228;BA.debugLine="If SendingFile Then";
if (_sendingfile) { 
 //BA.debugLineNum = 229;BA.debugLine="count = countingStream.count";
_count = _countingstream.getCount();
 //BA.debugLineNum = 230;BA.debugLine="total = totalSizeForSending";
_total = _totalsizeforsending;
 //BA.debugLineNum = 231;BA.debugLine="If count = total Then";
if (_count==_total) { 
 //BA.debugLineNum = 232;BA.debugLine="lblFile = currentFile & \" completed\"";
_lblfile = _currentfile+" completed";
 //BA.debugLineNum = 235;BA.debugLine="SendingFile = False";
_sendingfile = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 236;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 }else if(_receivingfile) { 
 //BA.debugLineNum = 239;BA.debugLine="count = astream.StreamReceived";
_count = _astream.getStreamReceived();
 //BA.debugLineNum = 240;BA.debugLine="total = astream.StreamTotal";
_total = _astream.getStreamTotal();
 };
 //BA.debugLineNum = 242;BA.debugLine="progressValue = 100 * count / total";
_progressvalue = (int) (100*_count/(double)_total);
 //BA.debugLineNum = 243;BA.debugLine="progressText = NumberFormat2(count / 1000, 0, 0,";
_progresstext = anywheresoftware.b4a.keywords.Common.NumberFormat2(_count/(double)1000,(int) (0),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.True)+"kb / "+anywheresoftware.b4a.keywords.Common.NumberFormat2(_total/(double)1000,(int) (0),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.True)+"kb";
 //BA.debugLineNum = 245;BA.debugLine="UpdateProgress";
_updateprogress();
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public static String  _updateprogress() throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Private Sub UpdateProgress";
 //BA.debugLineNum = 62;BA.debugLine="CallSub(Main, \"UpdateProgress\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"UpdateProgress");
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static String  _updateui() throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Private Sub UpdateUI";
 //BA.debugLineNum = 59;BA.debugLine="CallSub(Main, \"UpdateUI\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"UpdateUI");
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
}
